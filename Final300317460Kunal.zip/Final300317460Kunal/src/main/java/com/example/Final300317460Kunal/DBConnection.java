package com.example.Final300317460Kunal;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBConnection {
    public static Connection createConnection()
    {
        Connection con = null;
        String url = "jdbc:sqlserver://localhost/student"; //sql server URL and followed by the database name
        String username = "root"; //MySQL username
        String password = ""; //MySQL password
        try
        {
            try
            {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); //loading sql server driver
                System.out.println("SQL server loaded");
            }
            catch (ClassNotFoundException e)
            {
                System.out.println("SQL server not loaded, problem with jdbc Driver");
                e.printStackTrace();
            }
            con = DriverManager.getConnection(url, username, password); //attempting to connect to SQL server database

            System.out.println("Connection opened");
        }
        catch (Exception e)
        {
            System.out.println("error getting DB in DBConnection");

            e.printStackTrace();
        }
        return con;
    }
}