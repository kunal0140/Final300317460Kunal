package com.example.Final300317460Kunal;

public class StudentData {
    String sNumber;
    String sName;
    double gpa;

    public StudentData(String number, String name, double gpa) {
        this.sNumber = number;
        this.sName = name;
        this.gpa = gpa;
    }

}
