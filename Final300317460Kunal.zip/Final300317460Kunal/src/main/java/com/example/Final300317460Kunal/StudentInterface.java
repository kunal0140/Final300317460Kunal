package com.example.Final300317460Kunal;

public interface StudentInterface {
    public void addStudent();

    public void editStudent();

    public void deleteStudent();
}
