package com.example.Final300317460Kunal;

public class StudentService implements StudentInterface {
    @Override
    public void addStudent() {

    }

    @Override
    public void editStudent() {

    }

    @Override
    public void deleteStudent() {

    }
}
